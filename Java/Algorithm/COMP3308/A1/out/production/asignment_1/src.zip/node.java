import java.util.ArrayList;
import java.util.List;

public class node {
    public String value;
    public node father;
    public int cant;
    public List<node> kids = new ArrayList<>();
    public static List<node> expanded_list = new ArrayList<>();
    public static List<node> await_list = new ArrayList<>();

    public node(String value, node father){
        this.value = value;
        this.father = father;
        this.cant = Math.abs(Integer.parseInt(this.value) - Integer.parseInt(this.father.value));
    }
    public node(String value){
        this.value = value;
        this.cant = 0;
    }
    public static void getKids(node N){

        int s1 = Character.getNumericValue((N.value).charAt(0));
        int s2 = Character.getNumericValue((N.value).charAt(1));
        int s3 = Character.getNumericValue((N.value).charAt(2));

        String result1 = "";
        String result2 = "";
        String result3= "";
        String result4= "";
        String result5= "";
        String result6= "";


        if(s1 != 0){result1 = String.format("%03d",Integer.parseInt(Integer.toString((s1 - 1)) + Integer.toString(s2)  + Integer.toString(s3)));}
        if(s1 != 9){result2 = String.format("%03d",Integer.parseInt(Integer.toString((s1 + 1)) + Integer.toString(s2)  + Integer.toString(s3)));}
        if(s2 != 0){result3 = String.format("%03d",Integer.parseInt(Integer.toString(s1) + Integer.toString((s2 - 1)) + Integer.toString(s3)));}
        if(s2 != 9){result4 = String.format("%03d",Integer.parseInt(Integer.toString(s1) + Integer.toString((s2 + 1)) + Integer.toString(s3)));}
        if(s3 != 0){result5 = String.format("%03d",Integer.parseInt(Integer.toString(s1) + Integer.toString(s2) + Integer.toString((s3-1))));}
        if(s3 != 9){result6 = String.format("%03d",Integer.parseInt(Integer.toString(s1) + Integer.toString(s2) + Integer.toString((s3+1))));}

        if(N.cant == 0){
            if(s1 == 9) {
                node x = new node(result1,N);
                N.kids.add(x);
            }
            else if(s1 ==  0){
                node x = new node(result2,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result1,N);
                node xx = new node(result2,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
            if(s2 == 9) {
                node x = new node(result3,N);
                N.kids.add(x);
            }
            else if(s2 ==  0){
                node x = new node(result4,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result3,N);
                node xx = new node(result4,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
            if(s3 == 9) {
                node x = new node(result5,N);
                N.kids.add(x);
            }
            else if(s3 ==  0){
                node x = new node(result6,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result5,N);
                node xx = new node(result6,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
        }
        else if(N.cant == 100){
            if(s2 == 9) {
                node x = new node(result3,N);
                N.kids.add(x);
            }
            else if(s2 == 0){
                node x = new node(result4,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result3,N);
                node xx = new node(result4,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
            if(s3 == 9) {
                node x = new node(result5,N);
                N.kids.add(x);
            }
            else if(s3 ==  0){
                node x = new node(result6,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result5,N);
                node xx = new node(result6,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
        }
        else if(N.cant == 10){
            if(s1 == 9) {
                node x = new node(result1,N);
                N.kids.add(x);
            }
            else if(s1 ==  0){
                node x = new node(result2,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result1,N);
                node xx = new node(result2,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
            if(s3 == 9) {
                node x = new node(result5,N);
                N.kids.add(x);
            }
            else if(s3 ==  0){
                node x = new node(result6,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result5,N);
                node xx = new node(result6,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
        }
        else if(N.cant == 1){
            if(s1 == 9) {
                node x = new node(result1,N);
                N.kids.add(x);
            }
            else if(s1 ==  0){
                node x = new node(result2,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result1,N);
                node xx = new node(result2,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
            if(s2 == 9) {
                node x = new node(result3,N);
                N.kids.add(x);
            }
            else if(s2 ==  0){
                node x = new node(result4,N);
                N.kids.add(x);
            }
            else {
                node x = new node(result3,N);
                node xx = new node(result4,N);
                N.kids.add(x);
                N.kids.add(xx);
            }
        }
        for(node i:N.kids){
            if(!expanded_list.contains(i)){
            await_list.add(i);}
        }
        await_list.remove(await_list.indexOf(N));
        expanded_list.add(N);
    }
}
