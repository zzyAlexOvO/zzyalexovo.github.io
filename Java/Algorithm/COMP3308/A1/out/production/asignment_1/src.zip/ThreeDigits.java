import java.io.*;
import java.util.*;

public class ThreeDigits {
    public static int cant = 0;
    public static List<String> expanded_list = new ArrayList<>();
    public static List<String> await_list = new ArrayList<>();
    public static int count = 0;
    public static void expand(String s,int cant) {
        int s1 = Character.getNumericValue(s.charAt(0));
        int s2 = Character.getNumericValue(s.charAt(1));
        int s3 = Character.getNumericValue(s.charAt(2));

        count ++;

        String result1 = Integer.toString((s1 - 1)) + s.charAt(1)  + s.charAt(2);
        String result2 = Integer.toString((s1 + 1)) + s.charAt(1)  + s.charAt(2);
        String result3 = s.charAt(0) + Integer.toString((s2 - 1)) + s.charAt(2);
        String result4 = s.charAt(0) + Integer.toString((s2 + 1)) + s.charAt(2);
        String result5 = s.charAt(0) + s.charAt(1) + Integer.toString((s3 - 1));
        String result6 = s.charAt(0) + s.charAt(1) + Integer.toString((s3 + 1));

        if(cant == 0){
            if(s1 == 9) {
                await_list.add(result1);
            }
            else if(s1 ==  0){
                await_list.add(result2);
            }
            else {
                await_list.add(result1);
                await_list.add(result2);
            }
            if(s2 == 9) {
                await_list.add(result3);
            }
            else if(s2 ==  0){
                await_list.add(result4);
            }
            else {
                await_list.add(result3);
                await_list.add(result4);
            }
            if(s3 == 9) {
                await_list.add(result5);
            }
            else if(s3 ==  0){
                await_list.add(result6);
            }
            else {
                await_list.add(result5);
                await_list.add(result6);
            }
        }
        else if(cant == 1){
            if(s2 == 9) {
                await_list.add(result3);
            }
            else if(s2 ==  0){
                await_list.add(result4);
            }
            else {
                await_list.add(result3);
                await_list.add(result4);
            }
            if(s3 == 9) {
                await_list.add(result5);
            }
            else if(s3 ==  0){
                await_list.add(result6);
            }
            else {
                await_list.add(result5);
                await_list.add(result6);
            }
        }
        else if(cant == 2){
            if(s1 == 9){
                await_list.add(result1);
            }
            else if(s1 ==  0){
                await_list.add(result2);
            }
            else {
                await_list.add(result1);
                await_list.add(result2);
            }
            if(s3 == 9) {
                await_list.add(result5);
            }
            else if(s3 ==  0){
                await_list.add(result6);
            }
            else {
                await_list.add(result5);
                await_list.add(result6);
            }
        }
        else if(cant == 3){
            if(s1 == 9){
                await_list.add(result1);
            }
            else if(s1 ==  0){
                await_list.add(result2);
            }
            else {
                await_list.add(result1);
                await_list.add(result2);
            }
            if(s2 == 9) {
                await_list.add(result3);
            }
            else if(s2 ==  0){
                await_list.add(result4);
            }
            else {
                await_list.add(result3);
                await_list.add(result4);
            }
        }
        await_list.remove(await_list.indexOf(s));
        expanded_list.add(s);
    }

    public static void BFS(String num , String goal){
        node K =  new node(num);
        node.await_list.add(K);
        int cnt = 0;
        while(cnt<=100){
            if(node.await_list.get(0).value.equals(goal)){ break;}
            else{node.getKids(node.await_list.get(0));}
            cnt ++;
        }
    }

    public static void main(String[] args) throws IOException {
        File F = new File(args[1]);
        Scanner scan = new Scanner(F);
        String Start = scan.nextLine();
        String Goal = scan.nextLine();
        if(scan.hasNextLine()){String Forbidden = scan.nextLine();}
        BFS(Start,Goal);
        for(node i:node.expanded_list){
            System.out.println(i.value);
        }
        System.out.println("qaq");
        for(node i: node.await_list){
            System.out.println(i.value);
        }
    }
}